/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Modelo;

/**
 * 
 * @author Sammy Guergachi <sguergachi at gmail.com>
 */
public class Administrador {
    private String name = "admin";
    private String pass = "admin";   

    public String getName() {
        return name;
    }

    public String getPass() {
        return pass;
    }

    public Administrador() {
    }
}
